#  LINGO ist ein Indexierungssystem mit Grundformreduktion, Kompositumzerlegung, 
#  Mehrworterkennung und Relationierung.
#
#  Copyright (C) 2005  John Vorhauer
#
#  This program is free software; you can redistribute it and/or modify it under 
#  the terms of the GNU General Public License as published by the Free Software 
#  Foundation;  either version 2 of the License, or  (at your option)  any later
#  version.
#
#  This program is distributed  in the hope  that it will be useful, but WITHOUT
#  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
#  FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
#  You should have received a copy of the  GNU General Public License along with 
#  this program; if not, write to the Free Software Foundation, Inc., 
#  51 Franklin St, Fifth Floor, Boston, MA 02110, USA
#
#  For more information visit http://www.lex-lingo.de or contact me at
#  welcomeATlex-lingoDOTde near 50�55'N+6�55'E.
#
#  Lex Lingo rules from here on



=begin rdoc
== Reportable
Das Modul Reportable erm�glicht das setzen und hochz�hlen von statistischen Werten.
=end
module Reportable

	def init_reportable
		@counters = Hash.new(0)
		@prefix = ''
	end
	
	
	def report_prefix(prefix)
		@prefix = prefix
	end	
	
	
	def inc(counter)
		@counters[counter] += 1
	end
	
	
	def add(counter, value)
		@counters[counter] += value
	end
	
	
	def set(counter, value)
		@counters[counter] = value
	end


	def report
		rep = Hash.new
		@counters.each_pair { |stat, value|
			name = (@prefix=='') ? stat : @prefix+': '+stat
			rep[name] = value
		}
		rep
	end

end



=begin rdoc
== Cachable
Das Modul Cachable erm�glicht das Verwerten von zwischengespeicherten Ergebnisse
f�r einen schnelleren Zugriff. 
=end
module Cachable

	def init_cachable
		@cache = Hash.new(false)
	end

	
	def hit?(key)
		@cache.has_key?(key)
	end


	def store(key, value)
		res = value.nil? ? nil : value.dup
		@cache[key] = res
		value
	end

	
	def retrieve(key)
		value = @cache[key]
		value.nil? ? nil : value.dup
	end
end
